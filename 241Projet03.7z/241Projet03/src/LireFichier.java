import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class LireFichier{

	//attributs
	AdressesIP ip02;
	AdressesIP ip;

	//constructeur avec param�tre ip
	public LireFichier(AdressesIP ip) {
		super();
		this.ip = ip;
		this.ip02 = ip02;
	}

	// methode qui permet de lire dans un fichier
	public void lireFichiertxt(String path) {

		File f = new File(path);
		int nb = 0;
		try {
			if (f.exists()) {
				Scanner scan = new Scanner(f);

				while (scan.hasNextLine()) {
					String read = scan.nextLine();
					System.out.println(read);
				}
			}

		} catch(IOException | NoSuchElementException e) {
			System.out.println("Type d'erreur : " + e.getMessage());
		}
	}// fin methode

	public void lireFichierBinaire(String path) throws Exception {
		DataOutputStream out;
		int nombre;
		FileWriter fw = new FileWriter(path);
		IpConverter conv = new IpConverter();
		try {
			out = new DataOutputStream(
					new BufferedOutputStream(new FileOutputStream(path)));


			for (int i = 0; i < 1000; i++) {
				nombre = (int)(Math.random() * 10 + 1);
				fw.write("Adresse IP : " + conv.afficheDecimalToBinaire() + "\n");

			} 
			out.close();
		} catch (IOException ioe) {
			System.err.println(ioe);
			System.exit(1);
		}
	}

	// methode pour �crire dans un fichier texte tous les �l�ments d'un fichier
	public void ecrireFichier(String path) {

		try {
			FileWriter fw = new FileWriter(path);
			IpConverter conv = new IpConverter();

			fw.write("Adresse IP : " + ip.getAdresseIP() + "\n");

			fw.write("Adresse Reseau : " + ip.adresseReseau()+ "\n");
			fw.write("IP diffusion : " + ip.broadcast()+ "\n");
			fw.write("Prefix : " + ip.prefixIP()+ "\n");
			fw.write("Wildcard : " + ip.getWildcard()+ "\n");
			fw.write(conv.toString()+ "\n");
			fw.write("Masque du r�seau : " + ip.masqueReseau()+ "\n");
			fw.write("IP du r�seau : " + ip.adresseReseau()+ "\n");
			fw.write("Nombre de machine : " + ip.hotes()+ "\n");
			fw.write("IP premier machine : "  + ip.poste1()+ "\n");
			fw.write("IP dernier machine : "  + ip.dernierMachine()+ "\n");

			fw.close(); // fermer le fichier

		} catch (Exception e) {
			System.out.println("Erreur d'�criture du fichier");
		}

	}



}
