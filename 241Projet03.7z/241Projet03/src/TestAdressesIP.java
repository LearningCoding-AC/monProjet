
//Projet fait par : Leandro Zencovich, Elias Adadoua  Date: 09/5/2021


//classe pour tester la classe AdressesIP et IPConverter
public abstract class TestAdressesIP {

	public static void main(String[] args) throws Exception {

		//objets
		AdressesIP ip1 = new AdressesIP("200.200.200.0");
		AdressesIP ip2 = new AdressesIP("200.200.200.0/24");
		IpConverter conv = new IpConverter(ip1);
		LireFichier bin = new LireFichier(ip2);
		ip1.identifierType();

		
		//fichier
		String path = "testip.txt";
		//bin.lireFichierBinaire(path);
		
		//afficher chaque methode individuellement				

		System.out.println("Adresse Reseau : " + ip1.adresseReseau());

		System.out.println("Adresse Broadcast : " + ip1.broadcast());

		System.out.println("Prefix : " + ip2.prefixIP());

		System.out.println("Masque Inverse : " + ip2.getWildcard());

		System.out.println(conv.toString());

		System.out.println("Masque du r�seau : " + ip2.masqueReseau());

		System.out.println("IP du r�seau : " + ip1.adresseReseau());

		System.out.println("Nombre de machine : " + ip2.hotes());

		System.out.println("IP premier machine : "  + ip1.poste1());

		System.out.println("IP dernier machine : "  + ip1.dernierMachine());

		
	}









}


