import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import javax.swing.JScrollPane;
import java.awt.Canvas;

public class InterfaceProgramme {

	private JFrame frmProjetleandroZencovichElias;
	private JTextField txtIP;
	private JTextField txtprefix;
	private JTextField textIP;
	private JTextField textMasque;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {		
					//	InterfacePassword psw = new InterfacePassword();
					//	psw.main(null);


					InterfaceProgramme window = new InterfaceProgramme();
					window.frmProjetleandroZencovichElias.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public InterfaceProgramme() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmProjetleandroZencovichElias = new JFrame();
		frmProjetleandroZencovichElias.setTitle("Projet03-Leandro Zencovich, Elias Adadoua");
		frmProjetleandroZencovichElias.setBounds(100, 100, 474, 352);
		frmProjetleandroZencovichElias.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmProjetleandroZencovichElias.getContentPane().setLayout(null);

		JRadioButton rdbtnWildcard = new JRadioButton("Inverse (Wildcard)");
		rdbtnWildcard.setBounds(294, 101, 125, 23);
		frmProjetleandroZencovichElias.getContentPane().add(rdbtnWildcard);

		JLabel lblName = new JLabel("Calculateur de Masque IPv4");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblName.setForeground(Color.BLUE);
		lblName.setBounds(10, 11, 313, 25);
		frmProjetleandroZencovichElias.getContentPane().add(lblName);

		txtIP = new JTextField();
		txtIP.setBounds(10, 74, 133, 20);
		frmProjetleandroZencovichElias.getContentPane().add(txtIP);
		txtIP.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Adresse IP/ CIDR");
		lblNewLabel_1.setBounds(10, 59, 125, 14);
		frmProjetleandroZencovichElias.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("/");
		lblNewLabel_2.setBounds(148, 77, 46, 14);
		frmProjetleandroZencovichElias.getContentPane().add(lblNewLabel_2);

		txtprefix = new JTextField();
		txtprefix.setBounds(158, 74, 36, 20);
		frmProjetleandroZencovichElias.getContentPane().add(txtprefix);
		txtprefix.setColumns(10);

		textIP = new JTextField();
		textIP.setBounds(222, 56, 133, 20);
		frmProjetleandroZencovichElias.getContentPane().add(textIP);
		textIP.setColumns(10);

		JLabel lblNewLabel = new JLabel("Adresse IP / Masque");
		lblNewLabel.setBounds(222, 36, 133, 25);
		frmProjetleandroZencovichElias.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_3 = new JLabel("/");
		lblNewLabel_3.setBounds(363, 59, 46, 14);
		frmProjetleandroZencovichElias.getContentPane().add(lblNewLabel_3);

		textMasque = new JTextField();
		textMasque.setBounds(222, 74, 133, 20);
		frmProjetleandroZencovichElias.getContentPane().add(textMasque);
		textMasque.setColumns(10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(68, 146, 287, 104);
		frmProjetleandroZencovichElias.getContentPane().add(scrollPane);

		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setBorder(new LineBorder(new Color(0, 0, 0)));
		textArea.setLineWrap(true);

		JRadioButton rdbtnDirect = new JRadioButton("Direct\r\n");
		rdbtnDirect.setBounds(222, 101, 70, 23);
		frmProjetleandroZencovichElias.getContentPane().add(rdbtnDirect);

		JButton btnMasque = new JButton("Go");
		btnMasque.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnMasque.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnMasque.setBounds(373, 59, 51, 37);
		frmProjetleandroZencovichElias.getContentPane().add(btnMasque);

		JButton btnPrefix = new JButton("Go");
		btnPrefix.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnPrefix.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String skipLine = "\n";
				try {
					String txt1 = txtIP.getText();
					String txt2 = txtprefix.getText();
					String mix = txt1 + "/" + txt2;

					AdressesIP ip = new AdressesIP(txt1);
					AdressesIP prefix1 = new AdressesIP(mix);
					IpConverter conv = new IpConverter(ip);
					AdressesIP ip1 = new AdressesIP(txt2);

					ip.identifierType();		
					ip.trouverMasque();

					textArea.setText(
							"Adresse Reseau : " + ip.adresseReseau()+ skipLine + 
							"Adresse en Binaire : " + conv.toString() + skipLine +  
							"Masque de sous reseau : " + prefix1.masqueReseau() + skipLine +
							"Masque Inverse : " + prefix1.getWildcard() + skipLine +
							"Nombre de machines : " + prefix1.hotes() + skipLine + 
							"Premiere machine : " + ip.poste1()+skipLine + 
							"Premiere machine : " + ip.dernierMachine() + skipLine +
							"Prefix : "  + txt2);

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});
		btnPrefix.setBounds(10, 93, 61, 31);
		frmProjetleandroZencovichElias.getContentPane().add(btnPrefix);

		JButton btnNewButton = new JButton("Ajouter Machine");
		btnNewButton.setBounds(10, 279, 133, 23);
		frmProjetleandroZencovichElias.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("Supprimer machine");
		btnNewButton_1.setBounds(158, 279, 134, 23);
		frmProjetleandroZencovichElias.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("Quitter");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);

			}
		});
		btnNewButton_2.setBounds(359, 279, 89, 23);
		frmProjetleandroZencovichElias.getContentPane().add(btnNewButton_2);
	}
}
