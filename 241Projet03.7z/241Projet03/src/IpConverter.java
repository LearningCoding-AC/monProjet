
//Projet fait par : Leandro Zencovich, Elias Adadoua  Date: 09/5/2021



public class IpConverter extends AdressesIP{


	private static AdressesIP adresseIP;
	int[] binaryOctet;
	int octet;
	//protected JTextField afficheDecimalToBinaire;

	public IpConverter() {

	}

	public IpConverter(AdressesIP adresseIP) {
		this.adresseIP= adresseIP;
	}

	//Convertition en binaire en appelant la methode tobinaryStringUsingArray
	public static String afficheDecimalToBinaire()  {
		String DecimalBinaire = "" ;
		//out.write("Binaire : ");
		System.out.print("Binaire : ");


		String[] octetArray = adresseIP.getAdresseIP().split("\\.");
		if(Integer.parseInt(octetArray[0])  <= 255) {
			int compteur = 1;
			for (String string : octetArray) {


				int octet = Integer.parseInt(string);
				int[] binaryOctet = tobinaryStringUsingArray(octet);

				afficheTabBinaire(binaryOctet);
				if (compteur < 4 ) {
					System.out.print(".");

					compteur++;
				}
			}
		}else {
			System.out.println("L'adresse est eronn�e");
		}
		return DecimalBinaire;
	}




	//comment afficher ca
	//quelle variable quon doit convertir 
	public String BinaryToString()  {
		String DecimalBinaire = "";

		
		
		for(int s : binaryOctet) {
			
		}
		return DecimalBinaire;
	}
	
	private static void afficheTabBinaire(int[] binaryOctet) {
		// TODO Auto-generated method stub

	}

	//methode qui permet de transformer un string en binary
	private static int[] tobinaryStringUsingArray(int octet) {
		int binaryArray[] = new int[8];
		int index = binaryArray.length -1;
		while(octet != 0) {
			binaryArray[index] = octet %2;
			octet = octet /2;
			index--;
		}

		for (int i : binaryArray ) {

			System.out.print(i);


		}
		return binaryArray;
	}

	//getters/setters
	public AdressesIP getAddressageIp() {
		return adresseIP;
	}

	public void setAddressageIp(AdressesIP adresseIP) {
		this.adresseIP = adresseIP;
	}

	public String toString() {
		return afficheDecimalToBinaire();

	}

}








