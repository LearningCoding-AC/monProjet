import java.io.Serializable;
import java.util.Scanner;

//Projet fait par : Leandro Zencovich, Elias Adadoua  Date: 09/5/2021

public class AdressesIP{

	// attributs
	private String adresseIP;
	private ClassesIP type;
	private String Wildcard; 
	private int masknum;      
	private int prefixIP;
	private String masque;

	// constructeur sans param�tre
	public AdressesIP() {
		super();
	}

	// constructeur avec seulement l'adresse ip
	public AdressesIP(String adresseIP) {
		super();
		this.adresseIP = adresseIP;
	}

	// constructeur qui retourne son adresse IP ET son TYPE
	public AdressesIP(String adresseIP, ClassesIP classes) {
		super();
		this.adresseIP = adresseIP;
		this.type = type;

	}

	public AdressesIP(int prefix) {
		this.prefixIP = prefixIP;
	}


	// getters et setters
	public void setAdresseIP(String adresseIP) {
		this.adresseIP = adresseIP;
	}

	public String getAdresseIP() {
		return adresseIP;
	}

	public ClassesIP getTypes() {
		return type;
	}

	public void setTypes(ClassesIP classes) {
		this.type = classes;
	}

	// fin getters/setters

	// methode qui permet d'afficher mon masque individuellement
	public String trouverMasque() {

		if (type == ClassesIP.A) {
			return type.getMasque();
		} else if (type == ClassesIP.B) {
			return type.getMasque();
		} else if (type == ClassesIP.C) {
			return type.getMasque();
		}

		return adresseIP;

	}

	// methode pour acceder � IP du reseau
	public String adresseReseau() {

		String octets[] = { "0", ".0", ".0", ".0" };
		int lastidx = 0;
		int j = 0;
		int typeint = -1;

		if (type == ClassesIP.A) {
			typeint = 1;
		}
		if (type == ClassesIP.B) {
			typeint = 2;
		}
		if (type == ClassesIP.C) {
			typeint = 3;
		}
		for (int i = 0; i < typeint; i++) { // va en th�orie prendre la valeur de son type
			lastidx = j;
			j = adresseIP.indexOf('.', j + 1);
			octets[i] = adresseIP.substring(lastidx, j);
		}
		String join = String.join("", octets);
		return join;
	}


	// m�thode qui permet d'identifier mon type de network
	public String identifierType() throws Exception {
		String message = "";
		int idx = getAdresseIP().indexOf('.');
		String AdIP = getAdresseIP().substring(0, idx);
		int IP = Integer.parseInt(AdIP);
		try {
			if (IP > 0) {
				if (IP >= 1 && IP <= 126) { // Verifier si il est classe A
					setTypes(ClassesIP.A);
					return "A";

				} else if (IP >= 128 && IP <= 191) { // Verifier si il est classe B
					setTypes(ClassesIP.B);
					return "B";
				} else if (IP >= 192 && IP <= 223) { // Verifier si il est classe C
					setTypes(ClassesIP.C);
					return "C";
				}
			} else if (IP <= 0) { // juste au cas ou
				return "�crire une adresse IP positive!";
			}
		} catch (Exception ex) {
			if (IP == 127) {
				System.out.println(IP + "Ne pas �crire 127");
			}
		}
		return message;
	}
	

	//m�thode qui va retourner l'adresse IP du premier poste 
	public String poste1() {

		try {
			String octets[] = { "0", ".0", ".0", ".1" };
			int lastidx = 0;
			int j = 0;
			int typeint = -1;

			if (type == ClassesIP.A) {
				typeint = 1;
				for (int i = 0; i < typeint; i++) {
					lastidx = j;
					j = adresseIP.indexOf('.', j + 1);
					octets[i] = adresseIP.substring(lastidx, j);
				}
			}
			else if (type == ClassesIP.B) {
				typeint = 2;
				for (int i = 0; i < typeint; i++) {
					lastidx = j;
					j = adresseIP.indexOf('.', j + 1);
					octets[i] = adresseIP.substring(lastidx, j);
				}
			}
			else if (type == ClassesIP.C) {
				typeint = 3;
				for (int i = 0; i < typeint; i++) { 
					lastidx = j;
					j = adresseIP.indexOf('.', j + 1);
					octets[i] = adresseIP.substring(lastidx, j);
				}
			}

			String join = String.join("", octets);
			return join;
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return adresseIP;
	}

	//m�thode qui va retourner l'adresse IP du dernier poste 
	public String dernierMachine() throws Exception{
		try {
			String octets[] = { "0", ".0", ".0", ".254" };
			int lastidx = 0;
			int j = 0;
			int typeint = -1;

			if (type == ClassesIP.A) {
				typeint = 1;
				for (int i = 0; i < typeint; i++) {
					lastidx = j;
					j = adresseIP.indexOf('.', j + 1);
					octets[i] = adresseIP.substring(lastidx, j);
				}
			}
			else if (type == ClassesIP.B) {
				typeint = 2;
				for (int i = 0; i < typeint; i++) {
					lastidx = j;
					j = adresseIP.indexOf('.', j + 1);
					octets[i] = adresseIP.substring(lastidx, j);
				}
			}
			else if (type == ClassesIP.C) {
				typeint = 3;
				for (int i = 0; i < typeint; i++) { 
					lastidx = j;
					j = adresseIP.indexOf('.', j + 1);
					octets[i] = adresseIP.substring(lastidx, j);
				}
			}

			String join1 = String.join("", octets);
			return join1;
		}catch(Exception e) {
			System.out.println("Message d'erreur : " + e.getMessage());
		}
		return adresseIP;		

	}



	//methode qui va retourner l'adresse de diffusion
	public String broadcast() {

		try {
			String octets[] = { "0", ".255", ".255", ".255" };
			int lastidx = 0;
			int j = 0;
			int typeint = -1;

			if (type == ClassesIP.A) {
				typeint = 1;
				for (int i = 0; i < typeint; i++) {
					lastidx = j;
					j = adresseIP.indexOf('.', j + 1);
					octets[i] = adresseIP.substring(lastidx, j);
				}
			}
			else if (type == ClassesIP.B) {
				typeint = 2;
				for (int i = 0; i < typeint; i++) {
					lastidx = j;
					j = adresseIP.indexOf('.', j + 1);
					octets[i] = adresseIP.substring(lastidx, j);
				}
			}
			else if (type == ClassesIP.C) {
				typeint = 3;
				for (int i = 0; i < typeint; i++) { 
					lastidx = j;
					j = adresseIP.indexOf('.', j + 1);
					octets[i] = adresseIP.substring(lastidx, j);
				}
			}

			String join2 = String.join("", octets);
			return join2;
		}catch(Exception e) {
			System.out.println("Message d'erreur : " + e.getMessage());
		}
		return adresseIP;

	}


	//autre code pour PREFIX                                           
	public String prefixIP() {                                         
		String msg = "";                                               
		String[] octetIp = adresseIP.split("/");                         
		String ip = octetIp[0];                                        
		int prefixe;                      
		try {
			if (octetIp.length < 2) {                                      
				prefixe = 0;                                               
			} else {                                                       
				prefixe = Integer.parseInt(octetIp[1]);         
				prefixIP = prefixe;
			}      		
			msg = "" + prefixe;  
		}catch(Exception e) {
			System.out.println("Message d'erreur : " + e.getMessage());
		}
		return msg;                                                    
	}                                                                  

	//methode qui te donne le nombre d'hotes par bit
	public int hotes() {	
		int hotes = 0;
		String messageErreur = "";

		try {
			if(prefixIP > 0) {
				double x = Math.pow(2, (32 - prefixIP));
				x-=2;
				if(x < 0) {
					x = 0;		
				}		
				hotes = (int) x;
			}else {

			}	
		}catch(Exception e) {
			System.out.println("Prefix negatif ou egale � zero" + e.getMessage());
		}

		return (int) hotes;


	}



	//methode qui retourne le wildcard
	public String getWildcard() {


		String[] octetIp = adresseIP.split("/");
		String ip = octetIp[0];
		int prefixe;

		try {
			if (octetIp.length < 2) {
				prefixe = 0;
			} else {
				prefixe = Integer.parseInt(octetIp[1]);
			}

			if (prefixe == 0) {
				Wildcard = "255.255.255.255";
				this.Wildcard = "255.255.255.255";

			} else if (prefixe == 1) {
				Wildcard = "127.255.255.255";
				this.Wildcard = "127.255.255.255";
			} else if (prefixe == 2) {
				Wildcard = "63.255.255.255";
				this.Wildcard = "63.255.255.255";
			} else if (prefixe == 3) {
				Wildcard = "31.255.255.255";
				this.Wildcard = "31.255.255.255";
			} else if (prefixe == 4) {
				Wildcard = "15.255.255.255";
				this.Wildcard = "15.255.255.255";
			} else {
				if (prefixe == 5) {
					Wildcard = "7.255.255.255";
					this.Wildcard = "7.255.255.255";

				} else if (prefixe == 6) {
					Wildcard = "3.255.255.255";
					this.Wildcard = "3.255.255.255";
				} else if (prefixe == 7) {
					Wildcard = "1.255.255.255";
					this.Wildcard = "1.255.255.255";
				} else if (prefixe == 8) {
					Wildcard = "0.255.255.255";
					this.Wildcard = "0.255.255.255";
				} else if (prefixe == 9) {
					Wildcard = "0.127.255.255";
					this.Wildcard = "0.127.255.255";
				} else if (prefixe == 10) {
					Wildcard = "0.63.255.255";
					this.Wildcard = "0.63.255.255";
				} else if (prefixe == 11) {
					Wildcard = "0.31.255.255";
					this.Wildcard = "0.31.255.255";
				} else if (prefixe == 12) {
					Wildcard = "0.15.255.255";
					this.Wildcard = "0.15.255.255";
				} else if (prefixe == 13) {
					Wildcard = "0.7.255.255";
					this.Wildcard = "0.7.255.255";
				} else if (prefixe == 14) {
					Wildcard = "0.3.255.255";
					this.Wildcard = "0.3.255.255";

				} else if (prefixe == 15) {
					Wildcard = "0.1.255.255";
					this.Wildcard = "0.1.255.255";
				} else if (prefixe == 16) {
					Wildcard = "0.0.255.255";
					this.Wildcard = "0.0.255.255";
				} else if (prefixe == 17) {
					Wildcard = "0.0.127.255";
					this.Wildcard = "0.0.127.255";
				} else if (prefixe == 18) {
					Wildcard = "0.0.63.255";
					this.Wildcard = "0.0.63.255";
				} else if (prefixe == 19) {
					Wildcard = "0.0.31.255";
					this.Wildcard = "0.0.31.255";
				} else if (prefixe == 20) {
					Wildcard = "0.0.15.255";
					this.Wildcard = "0.0.15.255";
				} else if (prefixe == 21) {
					Wildcard = "0.0.7.255";
					this.Wildcard = "0.0.7.255";
				} else if (prefixe == 22) {
					Wildcard = "0.0.3.255";
					this.Wildcard = "0.0.3.255";
				} else if (prefixe == 23) {
					Wildcard = "0.0.1.255";
					this.Wildcard = "0.0.1.255";
				} else if (prefixe == 24) {
					Wildcard = "0.0.0.255";
					this.Wildcard = "0.0.0.255";
				} else if (prefixe == 25) {
					Wildcard = "0.0.0.127";
					this.Wildcard = "0.0.0.127";
				} else if (prefixe == 26) {
					Wildcard = "0.0.0.63";
					this.Wildcard = "0.0.0.63";
				} else if (prefixe == 27) {
					Wildcard = "0.0.0.31";
					this.Wildcard = "0.0.0.31";
				} else if (prefixe == 28) {
					Wildcard = "0.0.0.15";
					this.Wildcard = "0.0.0.15";
				} else if (prefixe == 29) {
					Wildcard = "0.0.0.7";
					this.Wildcard = "0.0.0.7";
				} else if (prefixe == 30) {
					Wildcard = "0.0.0.3";
					this.Wildcard = "0.0.0.3";
				} else if (prefixe == 31) {
					Wildcard = "0.0.0.1";
					this.Wildcard = "0.0.0.1";
				} else if (prefixe == 32) {
					Wildcard = "0.0.0.0";
					this.Wildcard = "0.0.0.0";
				} else {
					Wildcard = "Erreur";

					return Wildcard;
				}
			}

		}catch(Exception e) {
			System.out.println("Message d'erreur " + e.getMessage());
		}
		return Wildcard;
	}

	//methode masque reseau 
	public String masqueReseau() {


		String[] octetIp = adresseIP.split("/");
		String ip = octetIp[0];
		int prefixe;

		try {
			if (octetIp.length < 2) {
				prefixe = 0;
			} else {
				prefixe = Integer.parseInt(octetIp[1]);
			}

			if (prefixe == 0) {
				masque = "";
				this.masque = "";

			} else if (prefixe == 1) {
				masque = "128.0.0.0";
				this.masque = "128.0.0.0";
			} else if (prefixe == 2) {
				masque = "192.0.0.0";
				this.masque = "192.0.0.0";
			} else if (prefixe == 3) {
				masque = "224.0.0.0";
				this.masque = "224.0.0.0";
			} else if (prefixe == 4) {
				masque = "240.0.0.0";
				this.masque = "240.0.0.0";
			} else {
				if (prefixe == 5) {
					masque = "248.0.0.0";
					this.masque = "248.0.0.0";

				} else if (prefixe == 6) {
					masque = "252.0.0.0";
					this.masque = "252.0.0.0";
				} else if (prefixe == 7) {
					masque = "254.0.0.0";
					this.masque = "254.0.0.0";
				} else if (prefixe == 8) {
					masque = "255.0.0.0";
					this.masque = "255.0.0.0";
				} else if (prefixe == 9) {
					masque = "255.128.0.0";
					this.masque = "255.128.0.0";
				} else if (prefixe == 10) {
					masque = "255.192.0.0";
					this.masque = "255.192.0.0";
				} else if (prefixe == 11) {
					masque = "255.224.0.0";
					this.masque = "255.224.0.0";
				} else if (prefixe == 12) {
					masque = "255.240.0.0";
					this.masque = "255.240.0.0";
				} else if (prefixe == 13) {
					masque = "255.248.0.0";
					this.masque = "255.248.0.0";
				} else if (prefixe == 14) {
					masque = "255.252.0.0";
					this.masque = "255.252.0.0";

				} else if (prefixe == 15) {
					masque = "255.254.0.0";
					this.masque = "255.254.0.0";
				} else if (prefixe == 16) {
					masque = "255.255.0.0";
					this.masque = "255.255.0.0";
				} else if (prefixe == 17) {
					masque = "255.255.128.0";
					this.masque = "255.255.128.0";
				} else if (prefixe == 18) {
					masque = "255.255.192.0";
					this.masque = "255.255.192.0";
				} else if (prefixe == 19) {
					masque = "255.255.224.0";
					this.masque = "255.255.224.0";
				} else if (prefixe == 20) {
					masque = "255.255.240.0";
					this.masque = "255.255.240.0";
				} else if (prefixe == 21) {
					masque = "255.255.248.0	";
					this.masque = "255.255.248.0";
				} else if (prefixe == 22) {
					masque = "255.255.252.0";
					this.masque = "255.255.252.0";
				} else if (prefixe == 23) {
					masque = "255.255.254.0";
					this.masque = "255.255.254.0";
				} else if (prefixe == 24) {
					masque = "255.255.255.0";
					this.masque = "255.255.255.0";
				} else if (prefixe == 25) {
					masque = "255.255.255.128";
					this.masque = "255.255.255.128";
				} else if (prefixe == 26) {
					masque = "255.255.255.192";
					this.masque = "255.255.255.192";
				} else if (prefixe == 27) {
					masque = "255.255.255.224";
					this.masque = "255.255.255.224";
				} else if (prefixe == 28) {
					masque = "255.255.255.240";
					this.masque = "255.255.255.240";
				} else if (prefixe == 29) {
					masque = "255.255.255.248";
					this.masque = "255.255.255.248";
				} else if (prefixe == 30) {
					masque = "255.255.255.252";
					this.masque = "255.255.255.252";
				} else if (prefixe == 31) {
					masque = "255.255.255.254";
					this.masque = "255.255.255.254";
				} else if (prefixe == 32) {
					masque = "255.255.255.255";
					this.masque = "255.255.255.255";
				} else {
					masque = "Erreur";

					return masque;
				}
			}

		}catch(Exception e) {
			System.out.println("Message d'erreur " + e.getMessage());
		}
		return masque;
	}

}


