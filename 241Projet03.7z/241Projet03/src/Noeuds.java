
public class Noeuds {

	//attributs
	private MachinesPoste machines;
	private static int nbmachines= 0;


	//debut constructeur
	public Noeuds() {
		super();
	}

	public Noeuds(MachinesPoste machines) {
		super();
		this.machines = machines;
	}//fin constructeurs



	//getter/setters
	public MachinesPoste getMachines() {
		return machines;
	}

	public void setMachines(MachinesPoste machines) {
		this.machines = machines;
	}


	public void addPoste() {
		try {
			if ( machines == machines.IMPRIMANTE ){
				nbmachines ++;
				setMachines(MachinesPoste.IMPRIMANTE);
			}
			else if(machines == machines.MODEM) {
				nbmachines ++;
				setMachines(machines.MODEM);
			}
			else if(machines == machines.ORDINATEURS) {
				nbmachines ++;
				setMachines(machines.ORDINATEURS);

			}
			else if(machines == machines.ROUTEUR) {
				nbmachines ++;
				setMachines(machines.ROUTEUR);
			}
			else if(machines == machines.SERVEUR) {
				nbmachines ++;
				setMachines(machines.SERVEUR);
			}
		}catch(Exception e){
			System.out.println("Message : " + e.getMessage());
		}
	}


	public void supprimerPoste() {
		try {
			if ( machines == machines.IMPRIMANTE ){
				nbmachines --;
				setMachines(MachinesPoste.IMPRIMANTE);
			}
			else if(machines == machines.MODEM) {
				nbmachines --;
				setMachines(machines.MODEM);
			}
			else if(machines == machines.ORDINATEURS) {
				nbmachines --;
				setMachines(machines.ORDINATEURS);

			}
			else if(machines == machines.ROUTEUR) {
				nbmachines --;
				setMachines(machines.ROUTEUR);
			}
			else if(machines == machines.SERVEUR) {
				nbmachines --;
				setMachines(machines.SERVEUR);
			}


		}catch(Exception e){
			System.out.println("Message : " + e.getMessage());
		}

	}


}
