import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class TestFichier extends LireFichier{

	public TestFichier(AdressesIP ip) {
		super(ip);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		//objets
		AdressesIP ip1 = new AdressesIP("200.200.200.0");
		AdressesIP ip2 = new AdressesIP("200.200.200.0/24");
		IpConverter conv = new IpConverter(ip1);
		LireFichier bin = new LireFichier(ip2);
		ip1.identifierType();
		String ip = "200.200.200.0";



		//bin.lireFichierBinaire("./ip2.txt");


		BufferedWriter out =  new BufferedWriter (new FileWriter("./IP.txt"));
		out.write(String.valueOf("Adresse Reseau : " + ip1.adresseReseau()));
		out.newLine() ;
		out.write(String.valueOf("IP diffusion : " + ip1.broadcast()));
		out.newLine() ;
		out.write(String.valueOf("Prefix : " + ip2.prefixIP()));
		out.newLine() ;
		out.write(String.valueOf("Wildcard : " + ip2.getWildcard()));
		out.newLine() ;
		out.write(String.valueOf(conv.BinaryToString()));
		out.newLine() ;
		out.write(String.valueOf("Masque du r�seau : " + ip2.masqueReseau()));
		out.newLine() ;
		out.write(String.valueOf("IP du r�seau : " + ip1.adresseReseau()));
		out.newLine() ;
		out.write(String.valueOf("Nombre de machine : " + ip2.hotes()));
		out.newLine() ;
		out.write(String.valueOf("IP premier machine : "  + ip1.poste1()));
		out.newLine() ;
		out.write(String.valueOf("IP dernier machine : "  + ip1.dernierMachine()));

		out.newLine() ;
		out.close();
	}

}
