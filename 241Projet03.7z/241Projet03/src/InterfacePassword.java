import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Scanner;
import java.awt.event.ActionEvent;

public class InterfacePassword extends InterfaceProgramme{
	private JFrame frmSignIn;
	private JTextField textFieldUser;
	private JTextField textFieldPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InterfacePassword window1 = new InterfacePassword();
					window1.frmSignIn.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public InterfacePassword() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSignIn = new JFrame();
		frmSignIn.setTitle("Sign in");
		frmSignIn.setBounds(100, 100, 302, 133);
		frmSignIn.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSignIn.getContentPane().setLayout(null);

		textFieldUser = new JTextField();
		textFieldUser.setBounds(87, 8, 86, 20);
		frmSignIn.getContentPane().add(textFieldUser);
		textFieldUser.setColumns(10);

		textFieldPassword = new JTextField();
		textFieldPassword.setToolTipText("password");
		textFieldPassword.setBounds(87, 47, 86, 20);
		frmSignIn.getContentPane().add(textFieldPassword);
		textFieldPassword.setColumns(10);

		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setBounds(10, 11, 67, 14);
		frmSignIn.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(10, 50, 67, 14);
		frmSignIn.getContentPane().add(lblNewLabel_1);

		JButton btnNewButton = new JButton("Log in");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String User = textFieldUser.getText();
				String password = textFieldPassword.getText();
				InterfacePassword window2 = new InterfacePassword();

				if (User.equals("Elias")  && (password.equals("Leandro"))) {

					JOptionPane.showMessageDialog(textFieldUser, "Bienvenue " + User);
					
				}else if (User.equals("Leandro")  && (password.equals("Elias"))) {
					JOptionPane.showMessageDialog(textFieldUser, "Bienvenue " + User);
					
				}else {
					JOptionPane.showMessageDialog(textFieldUser, "mot de passe �rron�");

					return;


				}


			}
		});
		btnNewButton.setBounds(187, 46, 89, 23);
		frmSignIn.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Quitter");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_1.setBounds(310, 197, 89, 23);
}
}