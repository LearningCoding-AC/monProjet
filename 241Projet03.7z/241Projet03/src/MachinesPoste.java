
public enum MachinesPoste {

	//types de machines possibles (rajouter des adresses mac a chacun)
	IMPRIMANTE,ORDINATEURS,SERVEUR,ROUTEUR,MODEM
}
