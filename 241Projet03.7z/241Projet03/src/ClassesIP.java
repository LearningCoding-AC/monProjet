
public enum ClassesIP {


	// enum�ration avec leur masque associ� � chacun
	A("255.0.0.0"), B("255.255.0.0"), C("255.255.255.0");

	// attributs
	private String masque;

	// constructeur sans param�tres
	private ClassesIP() {
	}

	// constructeurs avec param�tres du masque
	private ClassesIP(String masque) {
		this.masque = masque;
	}

	
	// getters 
	public String getMasque() {
		return masque;
	}

}
